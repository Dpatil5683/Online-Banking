using iText.Kernel.Pdf;
using iText.Layout;
using iText.Layout.Element;
using iText.Kernel.Font;
using iText.IO.Font.Constants;
using Microsoft.AspNetCore.Mvc;
using OnlineBankingAPI.DTO;
using OnlineBankingAPI.Services;
using System.IO;
using iText.Kernel.Exceptions;
using Microsoft.AspNetCore.Authorization;

namespace OnlineBankingAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TransactionController : ControllerBase
    {
        private readonly ITransactionService _transactionService;

        public TransactionController(ITransactionService transactionService)
        {
            _transactionService = transactionService;
        }

        [HttpPost("transfer")]
        [Authorize(Roles = "User")]
        public async Task<IActionResult> TransferFunds([FromBody] TransactionDTO dto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var result = await _transactionService.TransferFundsAsync(dto);
                return Ok(new { Message = result });
            }
            catch (Exception ex)
            {
                return BadRequest(new { Error = ex.Message });
            }
        }

        [HttpGet("transactionSlip/{transactionId}")]
        public async Task<IActionResult> GetTransactionByIdAsync(int transactionId)
        {
            try
            {
                // Fetch transaction details
                var transaction = await _transactionService.GetTransactionByIdAsync(transactionId);

                // Check if transaction exists
                if (transaction == null)
                    return NotFound(new { Message = "Transaction not found." });

                // Return the transaction details as response
                return Ok(transaction);
            }
            catch (Exception ex)
            {
                // Handle exceptions and return error message
                return BadRequest(new { Error = ex.Message });
            }
        }
    }
}