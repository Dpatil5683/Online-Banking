using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using OnlineBankingAPI.DTO;
using OnlineBankingAPI.Service;

namespace OnlineBankingAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;

        public UserController(IUserService userService)
        {
            _userService = userService;
        }


        [HttpPost("submit")]
        public async Task<IActionResult> SubmitAccountRequest([FromBody] UserDTO userDTO)
        {
            var user = await _userService.CreateUserAsync(userDTO);
            return Ok(user);
        }

        [HttpPost("verify")]
        public async Task<IActionResult> VerifyRequest([FromBody] VerifyDTO verifyDTO)
        {
            var user = await _userService.VerifyUserAsync(verifyDTO);
            if (user == null)
                return NotFound("User not found.");

            return Ok(user);
        }

        [HttpPost("approve")]
       
        public async Task<IActionResult> ApproveRequest([FromBody] AdminApprovalDTO adminApprovalDTO)
        {
            var user = await _userService.ApproveUserAsync(adminApprovalDTO);
            if (user == null)
                return NotFound("User not found.");

            return Ok(user);
        }

        [HttpGet("status/{status}")]

        public async Task<IActionResult> GetUsersByStatus(string status)
        {
            try
            {
                var users = await _userService.GetUsersByStatusAsync(status);

                if (users == null || !users.Any())
                {
                    return NotFound(new { Message = "No users found with the specified status." });
                }

                return Ok(users);
            }
            catch (Exception ex)
            {
                // Log the exception (if logging is set up)
                return StatusCode(500, new { Message = "An error occurred while retrieving users.", Details = ex.Message });
            }
        }
        [HttpGet("user/{userId}")]
        public async Task<IActionResult> GetUserByIdAsync(int userId)
        {
            try
            {

                // Fetch user by ID using the service
                var user = await _userService.GetUserByIdAsync(userId);

                if (user == null)
                    return NotFound(new { Message = "User not found" });

                // Return the user details as response
                return Ok(user);
            }
            catch (Exception ex)
            {
                return BadRequest(new { Error = ex.Message });
            }
        }
    }
}


