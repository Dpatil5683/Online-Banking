using Microsoft.AspNetCore.Mvc;
using OnlineBankingAPI.DTO;
using OnlineBankingAPI.Service;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

namespace OnlineBankingAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MailController : ControllerBase
    {
        private readonly IMailService _mailService; 
        private readonly ILogger<MailController> _logger;

        public MailController(IMailService mailService, ILogger<MailController> logger)
        {
            _mailService = mailService; 
            _logger = logger;
        }

        // POST: api/mail/register
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterDTO registerDTO)
        {
            if (registerDTO == null)
            {
                _logger.LogWarning("Invalid registration attempt: Missing DTO");
                return BadRequest("Invalid registration data.");
            }

            try
            {
                _logger.LogInformation("Attempting registration for account: {AccountNumber}", registerDTO.AccountNumber);

                // Call the Register method of MailService to perform the registration logic
                var registrationResult = await _mailService.Register(registerDTO);

                if (registrationResult)
                {
                    _logger.LogInformation("Registration successful for account: {AccountNumber}", registerDTO.AccountNumber);
                    return Ok("Registration successful.");
                }
                else
                {
                    _logger.LogError("Registration failed for account: {AccountNumber}", registerDTO.AccountNumber);
                    return BadRequest("Registration failed.");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Error during registration for account: {AccountNumber}. Error: {ErrorMessage}", registerDTO.AccountNumber, ex.Message);
                return StatusCode(500, "An error occurred while processing your registration.");
            }
        }
        [HttpPost("UserIdthroughsend-otp")]
        public async Task<IActionResult> ForgotUserId([FromBody] ForgotUserIdDTO forgotUserIdDTO)
        {
            try
            {
                var response = await _mailService.ForgotUserId(forgotUserIdDTO);
                return Ok(response); // Return the success message and User ID response
            }
            catch (Exception ex)
            {
                return BadRequest(new { Message = ex.Message });
            }
        }
        [HttpPost("validate-otp-and-send-userid")]
public IActionResult ValidateOtpAndSendUserId([FromBody] OtpValidationDTO validateOtpDTO)
{
    try
    {
        // Validate OTP and send User ID if successful
        var result = _mailService.ValidateOtpAndSendUserId(validateOtpDTO.Email, validateOtpDTO.Otp);
        if (!result)
        {
            return BadRequest(new { Message = "Invalid OTP. Please try again." });
        }

        return Ok(new { Message = "User ID has been sent to your email successfully." });
    }
    catch (Exception ex)
    {
        return BadRequest(new { Message = ex.Message });
    }
}


        // POST: api/mail/sendotp
        [HttpPost("sendotp")]
        public IActionResult SendOtp([FromBody] string email)
        {
            if (string.IsNullOrEmpty(email))
            {
                _logger.LogWarning("Invalid OTP request: Missing email");
                return BadRequest("Email is required.");
            }

            try
            {
                _logger.LogInformation("Sending OTP to email: {Email}", email);

                // Call the GenerateAndSendOtp method to generate and send the OTP to the email
                var otp = _mailService.GenerateAndSendOtp(email);

                _logger.LogInformation("OTP sent successfully to email: {Email}", email);
                return Ok(new { Message = "OTP sent successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError("Error while sending OTP to email: {Email}. Error: {ErrorMessage}", email, ex.Message);
                return StatusCode(500, "An error occurred while sending the OTP.");
            }
        }
    }
}
