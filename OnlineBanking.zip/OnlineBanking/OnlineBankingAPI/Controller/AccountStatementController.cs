using Microsoft.AspNetCore.Mvc;
using OnlineBankingAPI.DTO;
using OnlineBankingAPI.Service;

namespace OnlineBankingAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountStatementController : ControllerBase
    {
        private readonly IAccountStatementService _accountStatementService;

        public AccountStatementController(IAccountStatementService accountStatementService)
        {
            _accountStatementService = accountStatementService;
        }

        // GET: api/AccountStatement/get-statement
        [HttpGet("get-statement")]
        public async Task<IActionResult> GetAccountStatement(
            [FromQuery] string accountNumber,
            [FromQuery] DateTime startDate,
            [FromQuery] DateTime endDate)
        {
            try
            {
                // Convert DateTime to DateOnly
                var requestDTO = new AccountStatementRequestDTO
                {
                    AccountNumber = accountNumber,
                    StartDate = DateOnly.FromDateTime(startDate),
                    EndDate = DateOnly.FromDateTime(endDate)
                };

                // Call the service to get account statement
                var accountStatement = await _accountStatementService.GetAccountStatement(requestDTO);

                // Return the response as JSON
                return Ok(accountStatement);
            }
            catch (Exception ex)
            {
                // Handle error
                return BadRequest(new { Message = ex.Message });
            }
        }
    }
}
