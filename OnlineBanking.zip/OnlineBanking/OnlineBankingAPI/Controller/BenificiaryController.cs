using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using OnlineBankingAPI.DTO;
using OnlineBankingAPI.Service;

namespace OnlineBankingAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BeneficiaryController : ControllerBase
    {
        private readonly IBeneficiaryService _beneficiaryService;

        public BeneficiaryController(IBeneficiaryService beneficiaryService)
        {
            _beneficiaryService = beneficiaryService;
        }

        
        [HttpPost("save")]
         [Authorize(Roles = "User")]
        public async Task<IActionResult> SaveBeneficiaryAsync([FromBody] BeneficiaryDTO beneficiaryDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Invalid data.");
            }

            var result = await _beneficiaryService.SaveBeneficiaryAsync(beneficiaryDTO);

            if (result)
            {
                return Ok("Beneficiary saved successfully.");
            }

            return Conflict("Beneficiary already exists with the same account number.");
        }
    }
}
