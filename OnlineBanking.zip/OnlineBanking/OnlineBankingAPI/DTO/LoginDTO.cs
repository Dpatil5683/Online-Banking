using System.ComponentModel.DataAnnotations;

namespace OnlineBankingAPI.DTO
{

public class LoginDTO
{
    [Required]
    public int UserId { get; set; }

    [Required]
    public string? LoginPassword { get; set; }
}
}