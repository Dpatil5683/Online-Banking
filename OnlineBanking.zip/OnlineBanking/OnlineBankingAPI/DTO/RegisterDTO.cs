using System.ComponentModel.DataAnnotations;
namespace OnlineBankingAPI.DTO
{

public class RegisterDTO
{
    [Required]
    public string? AccountNumber { get; set; }

    public string? Email { get; set; }

    [Required]
    [MinLength(6)]
    public string? LoginPassword { get; set; }

    [Required]
    [Compare("LoginPassword", ErrorMessage = "Passwords do not match.")]
    public string? ConfirmLoginPassword { get; set; }

    [Required]
    [MinLength(6)]
    public string? TransactionPassword { get; set; }

    [Required]
    [Compare("TransactionPassword", ErrorMessage = "Transaction passwords do not match.")]
    public string? ConfirmTransactionPassword { get; set; }

    [Required]
    public string? Otp { get; set; }
}
}