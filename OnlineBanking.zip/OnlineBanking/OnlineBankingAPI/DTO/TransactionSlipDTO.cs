public class TransactionSlipDTO
{
    public int TransactionId { get; set; }
    public string? TransactionType { get; set; }
    public string? BeneficiaryAccountNumber { get; set; }
    public DateTime Date { get; set; }
}
