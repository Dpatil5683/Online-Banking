namespace OnlineBankingAPI.DTO
{
    public class RegistrationDTO
    {
        public string? AccountNumber { get; set; }       
        public string? LoginPassword { get; set; }      
        public string? ConfirmLoginPassword { get; set; } 
        public string? TransactionPassword { get; set; }  
        public string? ConfirmTransactionPassword { get; set; } 
    }
}
