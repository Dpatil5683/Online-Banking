namespace OnlineBankingAPI.DTO
{
    public class OtpRequestDTO
    {
        public string? Email { get; set; } // User's email address
    }
}
