namespace OnlineBankingAPI.DTO
{
    public class OtpValidationDTO
    {
        public string? Email { get; set; } // User's email address
        public string? Otp { get; set; }   // OTP entered by the user
    }
}
