namespace OnlineBankingAPI.DTO
{
public class UserApprovalDTO
{
    public int UserId { get; set; }
    public string? Name { get; set; }
    
    public string? Status { get; set; }
    
}

}
