using System.ComponentModel.DataAnnotations;

namespace OnlineBankingAPI.DTO
{
public class TransactionDetailsDTO
{
    public string? BeneficiaryAccountNumber { get; set; }
    public string? TransactionType { get; set; }
    public decimal Amount { get; set; }
    public DateTime Date { get; set; }
    public string? Remark { get; set; }
}
}