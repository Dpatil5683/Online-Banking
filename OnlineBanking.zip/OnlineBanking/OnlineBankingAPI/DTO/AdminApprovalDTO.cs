namespace OnlineBankingAPI.DTO
{
public class AdminApprovalDTO
{
    public int UserId { get; set; }
    public bool IsApproved { get; set; }  

    public int AdminId { get; set; }

    public string? AdminPassword { get; set; }

}
}