namespace OnlineBankingAPI.DTO
{
public class VerifyDTO
{
    public int UserId { get; set; }
    public bool IsVerified { get; set; }  
}
}