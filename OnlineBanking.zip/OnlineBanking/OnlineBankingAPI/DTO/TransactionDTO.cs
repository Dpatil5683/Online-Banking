using System.ComponentModel.DataAnnotations;

namespace OnlineBankingAPI.DTO
{
    public class TransactionDTO
    {
    
        
        [Required]
        [StringLength(20)]
        public string? AccountNumber { get; set; }  // Sender's account number

        [Required]
        [StringLength(20)]
        public string? BeneficiaryAccountNumber { get; set; }  // Beneficiary's account number

        [Required]
        public decimal Amount { get; set; }  // Amount to transfer

        [Required]
        [StringLength(10)]
        public string? TransactionType { get; set; }  // NEFT, RTGS, IMPS

        public DateTime Date {get;set;}

        public string? Remark { get; set; }  // Optional remark for the transaction
    }
}
