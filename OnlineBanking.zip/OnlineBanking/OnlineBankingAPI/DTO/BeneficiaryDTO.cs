namespace OnlineBankingAPI.DTO
{
public class BeneficiaryDTO
{
    public string? BeneficiaryName { get; set; }
    public string? BeneficiaryAccountNumber { get; set; }
    public string? ConfirmAccountNumber { get; set; }
}
}
