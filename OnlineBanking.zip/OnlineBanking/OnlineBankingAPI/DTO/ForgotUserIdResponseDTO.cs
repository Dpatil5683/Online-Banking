namespace OnlineBankingAPI.DTO
{
public class ForgotUserIdResponseDTO
{
    public string? Message { get; set; }
    public string? UserId { get; set; }  
}
}