using System.Text.Json.Serialization;

namespace OnlineBankingAPI.DTO
{
public class UserDTO
{
    public string? Name { get; set; }
    public string? Email { get; set; }
    public string? MobileNumber { get; set; }

    public string? AadharNumber { get; set; }
    public DateOnly DOB { get; set; }
    public string? ResidentialAddress { get; set; }
    public string? PermanentAddress { get; set; }
    public string? Occupation { get; set; }

    [JsonIgnore]
     public string? Role {get;set;}
    
}
}