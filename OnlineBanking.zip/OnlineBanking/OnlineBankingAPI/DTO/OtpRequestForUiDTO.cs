namespace OnlineBankingAPI.DTO
{
    public class OtpRequestForUiDTO
    {
        public string? AccountNumber { get; set; }
        public string? Email { get; set; }
    }
}
