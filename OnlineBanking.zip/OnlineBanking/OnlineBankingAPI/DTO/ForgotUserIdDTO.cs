namespace OnlineBankingAPI.DTO
{
    public class ForgotUserIdDTO
    {
        public string? AccountNumber { get; set; }
        public string? Email { get; set; }
        public string? Otp { get; set; }
    }
}
