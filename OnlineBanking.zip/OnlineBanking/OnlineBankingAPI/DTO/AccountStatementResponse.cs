using System.ComponentModel.DataAnnotations;

namespace OnlineBankingAPI.DTO
{
public class AccountStatementResponseDTO
{
    public string? AccountNumber { get; set; }
    public string? AccountType { get; set; }
    public decimal Balance { get; set; }
    public List<TransactionDetailsDTO>? Transactions { get; set; }
}
}