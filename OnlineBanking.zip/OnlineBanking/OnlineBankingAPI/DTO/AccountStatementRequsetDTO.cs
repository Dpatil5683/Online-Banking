using System.ComponentModel.DataAnnotations;

namespace OnlineBankingAPI.DTO
{

public class AccountStatementRequestDTO
{
    [Required]
    public string? AccountNumber { get; set; }

    [Required]
    public DateOnly StartDate { get; set; }

    [Required]
    public DateOnly EndDate { get; set; }

        
    }
}