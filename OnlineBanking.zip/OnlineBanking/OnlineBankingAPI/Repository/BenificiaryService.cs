using Microsoft.EntityFrameworkCore;
using OnlineBankingAPI.DTO;
using OnlineBankingAPI.Models;

namespace OnlineBankingAPI.Service
{
public class BeneficiaryService : IBeneficiaryService
{
    private readonly OnlineBankingContext _context;

    public BeneficiaryService(OnlineBankingContext context)
    {
        _context = context;
    }

    public async Task<bool> SaveBeneficiaryAsync(BeneficiaryDTO beneficiaryDTO)
    {
        // Validate if Beneficiary Account Number and Confirm Account Number match
        if (beneficiaryDTO.BeneficiaryAccountNumber != beneficiaryDTO.ConfirmAccountNumber)
        {
            return false; // Account numbers do not match
        }

        // Create a new Beneficiary object from the DTO
        var beneficiary = new Beneficiary
        {
            BeneficiaryName = beneficiaryDTO.BeneficiaryName,
            BeneficiaryAccountNumber = beneficiaryDTO.BeneficiaryAccountNumber
        };

        // Validate if Beneficiary Account Number is already taken
        var existingBeneficiary = await (_context.Beneficiary?
                .FirstOrDefaultAsync(b => b.BeneficiaryAccountNumber == beneficiaryDTO.BeneficiaryAccountNumber) 
                ?? Task.FromResult<Beneficiary?>(null));

            if (existingBeneficiary != null)
            {
                return false; // Beneficiary already exists
            }


        // Save the new beneficiary
        _context.Beneficiary?.Add(beneficiary);
        await _context.SaveChangesAsync();
        return true;
    }
}
}