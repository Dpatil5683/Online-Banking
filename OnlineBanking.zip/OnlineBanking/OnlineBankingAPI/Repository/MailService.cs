using System;
using System.Net;
using System.Net.Mail;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using OnlineBankingAPI.DTO;
using OnlineBankingAPI.Models;
using OnlineBankingAPI.Service;

public class MailService : IMailService
{
    private readonly string _smtpHost = "smtp.gmail.com"; // Replace with your SMTP host
    private readonly int _smtpPort = 587; // SMTP port
    private readonly string _smtpUser = "dpatil5683@gmail.com"; // Your email
    private readonly string _smtpPass = "dqud dzcn tjxc gkkx"; 
    private readonly IMemoryCache _cache; // Injected IMemoryCache

    private readonly OnlineBankingContext _context;

    public MailService(IMemoryCache memoryCache, OnlineBankingContext context)
    {
        _cache = memoryCache;
        _context = context;
    }

    public string GenerateAndSendOtp(string email)
    {
        // Generate a 6-digit OTP and send it to the email
        var otp = new Random().Next(100000, 999999).ToString();
        var expiry = TimeSpan.FromMinutes(5); // OTP valid for 5 minutes

        // Store OTP in cache with expiration
        var normalizedEmail = email.Trim().ToLower();
        _cache.Set(normalizedEmail, otp, expiry);

        // Prepare email content
        var mailRequest = new MailRequestDTO
        {
            ToEmail = email,
            Subject = "Your OTP for Registration",
            Body = $"Your OTP is {otp}. It will expire in 5 minutes."
        };

        // Send email
        SendEmail(mailRequest);

        return otp; // Return OTP for testing purposes only (remove in production)
    }

    public bool ValidateOtp(string email, string otp)
    {
        var normalizedEmail = email.Trim().ToLower();

        // Check if OTP exists in cache
        if (_cache.TryGetValue(normalizedEmail, out string? storedOtp))
        {
            if (storedOtp == otp.Trim())
            {
                _cache.Remove(normalizedEmail); // Remove OTP after successful validation
                return true; // OTP validated
            }
        }

        return false; // Invalid OTP
    }
    public async Task<bool> Register(RegisterDTO registerDTO)
    {


        // Step 1: Check if the Account exists by AccountNumber
        var account = await _context.Account
            .FirstOrDefaultAsync(a => a.AccountNumber == registerDTO.AccountNumber);

        if (account == null)
        {
            throw new Exception("Account not found.");
        }

        // Step 2: Validate OTP sent to the user's email
        var isOtpValid = ValidateOtp(registerDTO.Email, registerDTO.Otp);
        if (!isOtpValid)
        {

            throw new Exception("Invalid OTP.");
        }
        account.LoginPassword = registerDTO.LoginPassword;
        account.TransactionPassword = registerDTO.TransactionPassword;

        // Save changes to the database
        await _context.SaveChangesAsync();
        return true; // Registration successful
    }
    public async Task<ForgotUserIdResponseDTO> ForgotUserId(ForgotUserIdDTO forgotUserIdDTO)
    {
        // Step 1: Check if the Account exists by AccountNumber and Email
        var account = await _context.Account
            .Include(a => a.User) // Assuming there's a User navigation property
            .FirstOrDefaultAsync(a => a.AccountNumber == forgotUserIdDTO.AccountNumber && a.User.Email == forgotUserIdDTO.Email);

        if (account == null)
        {
            throw new Exception("Account or email not found.");
        }

        // Step 2: Generate OTP and send it to the provided email
        var otp = GenerateAndSendOtp(forgotUserIdDTO.Email);

        

        // Cache the account details temporarily for step 3
        var normalizedEmail = forgotUserIdDTO.Email.Trim().ToLower();
        _cache.Set($"{normalizedEmail}_UserId", account.UserId, TimeSpan.FromMinutes(5));

        return new ForgotUserIdResponseDTO
        {
            Message = "OTP sent successfully. Please validate it to retrieve your User ID."
        };
    }

    // New Method: Validate OTP and Send User ID
    public bool ValidateOtpAndSendUserId(string email, string otp)
    {
        var normalizedEmail = email.Trim().ToLower();

        // Step 1: Validate the OTP
        if (!_cache.TryGetValue(normalizedEmail, out string? storedOtp) || storedOtp != otp.Trim())
        {
            return false; // OTP validation failed
        }

        // Step 2: Retrieve the User ID from cache
        if (!_cache.TryGetValue($"{normalizedEmail}_UserId", out int? userId))
        {
            throw new Exception("User ID information is missing. Please retry the process.");
        }

        // Step 3: Send the User ID to the user's email
        var mailRequest = new MailRequestDTO
        {
            ToEmail = email,
            Subject = "Your User ID Retrieval",
            Body = $"Dear user, your User ID is: {userId}. Please keep it secure."
        };

        SendEmail(mailRequest);

        // Remove cached data after successful operation
        _cache.Remove(normalizedEmail);
        _cache.Remove($"{normalizedEmail}_UserId");

        return true;
    }

    private void SendEmail(MailRequestDTO mailRequest)
    {
        try
        {
            using var client = new SmtpClient(_smtpHost, _smtpPort)
            {
                Credentials = new NetworkCredential(_smtpUser, _smtpPass),
                EnableSsl = true
            };

            var mailMessage = new MailMessage
            {
                From = new MailAddress(_smtpUser),
                Subject = mailRequest.Subject,
                Body = mailRequest.Body,
                IsBodyHtml = true
            };
            mailMessage.To.Add(mailRequest.ToEmail);

            client.Send(mailMessage);
        }
        catch (Exception ex)
        {
            throw new Exception($"Failed to send email: {ex.Message}");
        }
    }

    void IMailService.SendEmail(MailRequestDTO mailRequest)
    {
        throw new NotImplementedException();
    }
}
