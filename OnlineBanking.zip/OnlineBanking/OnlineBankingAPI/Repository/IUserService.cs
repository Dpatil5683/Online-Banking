using OnlineBankingAPI.DTO;

namespace OnlineBankingAPI.Service
{
public interface IUserService
{
    Task<Users> CreateUserAsync(UserDTO userDTO);
    Task<Users> VerifyUserAsync(VerifyDTO verifyDTO);
    Task<Users> ApproveUserAsync(AdminApprovalDTO adminApprovalDTO);
    Task<List<UserApprovalDTO>> GetUsersByStatusAsync(string status);

   Task<UserDTO> GetUserByIdAsync(int userId);

   Task<Accounts> GetAccountByIdAsync(int accountId);
}
}
