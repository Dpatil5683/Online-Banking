using OnlineBankingAPI.DTO;
using System.Threading.Tasks;

namespace OnlineBankingAPI.Service
{
public interface IAccountStatementService
{
     Task<AccountStatementResponseDTO> GetAccountStatement(AccountStatementRequestDTO requestDTO);
}
}