using OnlineBankingAPI.DTO;
namespace OnlineBankingAPI.Services
{
    public interface ITransactionService
    {
        Task<string> TransferFundsAsync(TransactionDTO transactionDTO);

        Task<TransactionSlipDTO> GetTransactionByIdAsync(int transactionId);

    }
}