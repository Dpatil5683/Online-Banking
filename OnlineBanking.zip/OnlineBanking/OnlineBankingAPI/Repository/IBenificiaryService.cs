using OnlineBankingAPI.DTO;

namespace OnlineBankingAPI.Service
{

public interface IBeneficiaryService
{
    Task<bool> SaveBeneficiaryAsync(BeneficiaryDTO beneficiaryDTO);
}
}