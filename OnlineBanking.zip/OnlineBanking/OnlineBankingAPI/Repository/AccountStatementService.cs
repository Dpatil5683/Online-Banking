using Microsoft.EntityFrameworkCore;
using OnlineBankingAPI.DTO;
using OnlineBankingAPI.Models;

namespace OnlineBankingAPI.Service
{
public class AccountStatementService: IAccountStatementService

{
    private readonly OnlineBankingContext _context;

    public AccountStatementService(OnlineBankingContext context)
    {
        _context = context;
    }

    public async Task<AccountStatementResponseDTO> GetAccountStatement(AccountStatementRequestDTO requestDTO)
    {
        // Step 1: Find the account based on AccountNumber
        var account = await _context.Account
            .FirstOrDefaultAsync(a => a.AccountNumber == requestDTO.AccountNumber);

        if (account == null)
        {
            throw new Exception("Account not found.");
        }

        // Step 2: Get transactions within the date range for the given AccountNumber
        var transactions = await _context.Transaction
    .Where(t => t.AccountNumber == requestDTO.AccountNumber 
                && t.Date >= requestDTO.StartDate.ToDateTime(TimeOnly.MinValue)
                && t.Date <= requestDTO.EndDate.ToDateTime(TimeOnly.MaxValue))
    .ToListAsync();


        // Step 3: Map to the response DTO
        var responseDTO = new AccountStatementResponseDTO
        {
            AccountNumber = account.AccountNumber,
            AccountType = account.AccountType,
            Balance = account.Balance,
            Transactions = transactions.Select(t => new TransactionDetailsDTO
            {
                BeneficiaryAccountNumber = t.BeneficiaryAccountNumber,
                TransactionType = t.TransactionType,
                Amount = t.Amount,
                Date = t.Date,
                Remark = t.Remark
            }).ToList()
        };

        return responseDTO;
    }
}

   
}