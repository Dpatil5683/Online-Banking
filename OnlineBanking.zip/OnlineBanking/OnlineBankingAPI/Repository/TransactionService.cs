using Microsoft.EntityFrameworkCore;
using OnlineBankingAPI.DTO;
using OnlineBankingAPI.Models;
using OnlineBankingAPI.Services;

public class TransactionService : ITransactionService
{
    private readonly OnlineBankingContext _context;

    public TransactionService(OnlineBankingContext context)
    {
        _context = context;
    }

    public async Task<string> TransferFundsAsync(TransactionDTO dto)
    {
        // Check if account and beneficiary exist
        var account = await _context.Account.FirstOrDefaultAsync(a => a.AccountNumber == dto.AccountNumber);
        var beneficiary = await _context.Beneficiary.FirstOrDefaultAsync(b => b.BeneficiaryAccountNumber == dto.BeneficiaryAccountNumber);

        if (account == null)
            throw new Exception("Invalid account number.");

        if (beneficiary == null)
            throw new Exception("Invalid beneficiary account number.");

        if (account.Balance < dto.Amount)
            throw new Exception("Insufficient balance.");

        // Deduct amount from user's account
        account.Balance -= dto.Amount;

        // Log transaction
        var transaction = new Transaction
        {
            AccountNumber = dto.AccountNumber,
            BeneficiaryAccountNumber = dto.BeneficiaryAccountNumber,
            TransactionType = dto.TransactionType,
            Amount = dto.Amount,
            Date = DateTime.Now,
            Remark = dto.Remark
        };

        await _context.Transaction.AddAsync(transaction);
        await _context.SaveChangesAsync();

        return "Transaction successful.";
    }
    public async Task<TransactionSlipDTO> GetTransactionByIdAsync(int transactionId)
    {
        var transaction = await _context.Transaction
            .FirstOrDefaultAsync(t => t.TransactionId == transactionId);

        if (transaction == null)
            return null;

        return new TransactionSlipDTO
        {
            TransactionId=transaction.TransactionId,
            BeneficiaryAccountNumber = transaction.BeneficiaryAccountNumber,
            TransactionType = transaction.TransactionType,         
            Date = transaction.Date,
            
        };
    }



}
