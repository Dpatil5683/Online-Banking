using System.Security.Claims;
using Microsoft.EntityFrameworkCore;
using OnlineBankingAPI.DTO;
using OnlineBankingAPI.Models;

namespace OnlineBankingAPI.Service
{
    public class UserService : IUserService
    {
        private readonly OnlineBankingContext _context;

        public UserService(OnlineBankingContext context)
        {
            _context = context;
        }

        // user account request
        public async Task<Users> CreateUserAsync(UserDTO userDTO)
        {
            var user = new Users
            {
                Name = userDTO.Name,
                Email = userDTO.Email,
                MobileNumber = userDTO.MobileNumber,
                AadharNumber = userDTO.AadharNumber,
                DOB = userDTO.DOB,
                ResidentialAddress = userDTO.ResidentialAddress,
                PermanentAddress = userDTO.PermanentAddress,
                Occupation = userDTO.Occupation,
                Status = "Pending",
                Role = userDTO.Role ?? "User"
            };

            _context.User?.Add(user);
            await _context.SaveChangesAsync();

            return user;
        }


        public async Task<Users> VerifyUserAsync(VerifyDTO verifyDTO)
        {
            var user = await _context.User.FindAsync(verifyDTO.UserId);
            if (user == null)
                return null;

            user.Status = verifyDTO.IsVerified ? "Verified" : "Pending";
            await _context.SaveChangesAsync();

            return user;
        }


        public async Task<Users> ApproveUserAsync(AdminApprovalDTO adminApprovalDTO)
        {
            var user = await _context.User.FindAsync(adminApprovalDTO.UserId);
            if (user == null)
                return null;


            var admin = await _context.Admin.FindAsync(adminApprovalDTO.AdminId);
            if (admin == null)
            {
                throw new InvalidOperationException("Admin not found");
            }

            if (adminApprovalDTO.IsApproved)
            {

                var account = new Accounts
                {
                    UserId = user.UserId,
                    AccountNumber = "ACC" + new Random().Next(1000, 9999),
                    AccountType = "Savings",
                    Balance = 1000,

                };

                _context.Account?.Add(account);
                user.Status = "Approved";
                // user.AdminId = adminApprovalDTO.AdminId;
                await _context.SaveChangesAsync();
            }
            else
            {
                user.Status = "Rejected";
                await _context.SaveChangesAsync();
            }

            return user;
        }

        public async Task<List<UserApprovalDTO>> GetUsersByStatusAsync(string status)
        {
            return await _context.User
                .Where(u => u.Status == status)
                .Select(u => new UserApprovalDTO
                {
                    UserId = u.UserId,
                    Name = u.Name,
                    Status = u.Status,
                    
                })
                .ToListAsync();
        }

        public async Task<UserDTO> GetUserByIdAsync(int userId)
        {
            
            // Fetch the user from the database by userId
            var user = await _context.User.FindAsync(userId);

            // If the user does not exist, return null or you can throw a NotFoundException
            if (user == null)
                return null;  // Or you can throw a new Exception("User not found");

            // Map the user entity to a UserDTO and return it
            return new UserDTO
            {

                Name = user.Name,
                Email = user.Email,
                MobileNumber = user.MobileNumber,
                AadharNumber = user.AadharNumber,
                DOB = user.DOB,
                ResidentialAddress = user.ResidentialAddress,
                PermanentAddress = user.PermanentAddress,
                Occupation = user.Occupation,

            };
        }
        public async Task<Accounts> GetAccountByIdAsync(int accountId)
{
    // Fetch the account from the database
    var account = await _context.Account.FindAsync(accountId);

    // Return the account or null if not found
    return account;
}


    }
}
