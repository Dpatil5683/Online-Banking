using OnlineBankingAPI.DTO;

namespace OnlineBankingAPI.Service
{

public interface ILoginService
{
    Task<string> LoginAsync(LoginDTO loginDto); // Login method that validates user and returns a JWT token
    Task ResetPasswordAsync(PasswordResetDTO passwordResetDto); // Method to reset the password
}
}