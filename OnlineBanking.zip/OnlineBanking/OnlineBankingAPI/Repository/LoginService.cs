using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using OnlineBankingAPI.DTO;
using OnlineBankingAPI.Models;

namespace OnlineBankingAPI.Service
{
    public class LoginService : ILoginService
    {
        private readonly OnlineBankingContext _context;
        private readonly IConfiguration _configuration;
        private const int MaxLoginAttempts = 3;

        public LoginService(OnlineBankingContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        public async Task<string> LoginAsync(LoginDTO loginDto)
        {
            // Find account by UserId
            var account = await _context.Account
                .Include(a => a.User)  // Ensure User is included to avoid null reference
                .FirstOrDefaultAsync(a => a.UserId == loginDto.UserId);

            if (account == null)
                throw new UnauthorizedAccessException("Invalid credentials.");

            var admin= _context.Admin.Find(loginDto.UserId);
            if(loginDto.LoginPassword==admin.AdminPassword)
            {
                 return GenerateJwtToken(account.User);
            }
        

            // If account is locked, prevent login
            if (account.IsLocked)
                throw new UnauthorizedAccessException("Your account is locked. Please reset your password.");

            // If login attempts exceed the limit, lock the account
            if (account.FailedLoginAttempts >= MaxLoginAttempts)
            {
                account.IsLocked = true;
                await _context.SaveChangesAsync();
                throw new UnauthorizedAccessException("Your account has been locked due to multiple failed login attempts.");
            }

            // Simple password comparison
            if (account.LoginPassword != loginDto.LoginPassword)
            {
                account.FailedLoginAttempts++;  // Increment failed attempts on invalid login
                await _context.SaveChangesAsync();
                throw new UnauthorizedAccessException("Invalid credentials.");
            }

            // Reset failed attempts on successful login
            account.FailedLoginAttempts = 0;
            await _context.SaveChangesAsync();

            // Generate and return JWT token
            return GenerateJwtToken(account.User);
        }

        // Generate JWT token
        private string GenerateJwtToken(Users user)
{
    try
    {
        var claims = new[]
        {
            new Claim(JwtRegisteredClaimNames.Sub, _configuration["Jwt:Subject"] ?? "default-subject"),
            new Claim(JwtRegisteredClaimNames.Email, user.Email),
            new Claim(ClaimTypes.NameIdentifier, user.UserId.ToString()),  // User ID as the name identifier
            new Claim("UserId", user.UserId.ToString()),                   // Optional extra claim
            new Claim(ClaimTypes.Role, user.Role),
            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()) // Unique identifier for the token
        };

        var key = Encoding.ASCII.GetBytes(_configuration["Jwt:SecretKey"]);

        // Check if the key length is sufficient (recommended 32 bytes for HMAC-SHA256)
        if (key.Length < 32)
        {
            throw new InvalidOperationException("Secret key must be at least 32 bytes.");
        }

        var symmetricKey = new SymmetricSecurityKey(key);
        var signingCredentials = new SigningCredentials(symmetricKey, SecurityAlgorithms.HmacSha256);

        var expiration = DateTime.UtcNow.AddMinutes(60); // Token valid for 60 minutes

        var token = new JwtSecurityToken(
            issuer: _configuration["Jwt:Issuer"],
            audience: _configuration["Jwt:Audience"],
            claims: claims,
            expires: expiration,
            signingCredentials: signingCredentials
        );

        // Return the JWT token as a string
        return new JwtSecurityTokenHandler().WriteToken(token);
    }
    catch (Exception ex)
    {
        // Log the error
        throw new ApplicationException("Error generating JWT token.", ex);
    }
}
        public async Task ResetPasswordAsync(PasswordResetDTO passwordResetDto)
        {
            // Ensure passwords match
            if (passwordResetDto.NewPassword != passwordResetDto.ConfirmPassword)
            {
                throw new ArgumentException("Password and confirmation password do not match.");
            }

            // Find the account by UserId (or AccountNumber depending on your preference)
            var account = await _context.Account
                .FirstOrDefaultAsync(a => a.UserId == passwordResetDto.UserId);  // Ensure UserId is used here

            if (account == null)
            {
                throw new ArgumentException("Account not found.");
            }

            // Update the password and reset failed attempts
            account.LoginPassword = passwordResetDto.NewPassword;
            account.FailedLoginAttempts = 0;
            account.IsLocked = false;  // Unlock account

            await _context.SaveChangesAsync();
        }


        
    }
}
