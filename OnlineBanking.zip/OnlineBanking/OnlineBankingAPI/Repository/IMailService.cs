using AutoMapper.Internal;
using OnlineBankingAPI.DTO;

namespace OnlineBankingAPI.Service
{

public interface IMailService
{
    string GenerateAndSendOtp(string email);
    bool ValidateOtp(string email, string otp); // Method for OTP validation

    Task<bool> Register(RegisterDTO registerDTO);

    bool ValidateOtpAndSendUserId(string email, string otp);

   Task<ForgotUserIdResponseDTO> ForgotUserId(ForgotUserIdDTO forgotUserIdDTO);

    void SendEmail(MailRequestDTO mailRequest);
}
}