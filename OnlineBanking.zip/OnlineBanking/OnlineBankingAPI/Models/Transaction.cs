using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

public class Transaction
{
    [Key]
    public int TransactionId { get; set; } 

    [Required]
    public string? AccountNumber { get; set; } // FK to the Accounts table 
    public Accounts? Account {get;set;} //naviga


    [Required]
    public string? BeneficiaryAccountNumber { get; set; } // FK to the Accounts or Beneficiary table (recipient)
    public Beneficiary? Beneficiary{get;set;}
    
    [Required]
    [StringLength(10)]
    public string? TransactionType { get; set; } 

    [Required]
    [Column(TypeName = "decimal(15,2)")]
    public decimal Amount { get; set; } 

    [Required]
    public DateTime Date { get; set; } 

    [StringLength(255)]
    public string? Remark { get; set; } 

    


}
