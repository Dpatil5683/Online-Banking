using System.ComponentModel.DataAnnotations;

public class Users
{
    
    [Key]
    public int UserId { get; set; }

    [Required]
    [StringLength(100)]
    public string? Name { get; set; }

    [Required]
    [EmailAddress]
    public string? Email { get; set; }

    [Required]
    [StringLength(15)]
    public string? MobileNumber { get; set; }

    [Required]
    [StringLength(12)]
    public string? AadharNumber { get; set; }

    [Required]
    public DateOnly DOB { get; set; }

    public string? ResidentialAddress { get; set; }

    public string? PermanentAddress { get; set; }

    public string? Occupation { get; set; }

    public string? Status { get; set; }  

    public string? Role {get;set;}
    // Navigation property for one-to-one relationship
    public Accounts? Account { get; set; }

    
}
