using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

public class Accounts
{
    [Key]
    public string? AccountNumber { get; set; }

    [Required]
    [ForeignKey("User")]
    public int UserId { get; set; }

    // [Required]
    // public string? AccountNumber { get; set; }

    [Required]
    public string? AccountType { get; set; }

    [Column(TypeName = "decimal(18,2)")]
    public decimal Balance { get; set; }

    
    public string? LoginPassword { get; set; }

    
    public string? TransactionPassword { get; set; }

    // Navigation property for one-to-one relationship
    public Users? User { get; set; }

    public bool IsLocked { get; set; } 

    public int FailedLoginAttempts { get; set; } 

   

    public virtual ICollection<Transaction>? Transactions { get; set; } // List of Transactions where this beneficiary is the recipient
}
