using System.ComponentModel.DataAnnotations;

public class Beneficiary
{
    [Key]
    public string? BeneficiaryAccountNumber { get; set; } 
    
    [Required]
    [StringLength(255)]
    public string? BeneficiaryName { get; set; } 

    // [Required]
    // [StringLength(20)]
    // public string? BeneficiaryAccountNumber { get; set; } 

    // Navigation property for the related transactions
    public virtual ICollection<Transaction>? Transactions { get; set; } // List of Transactions where this beneficiary is the recipient
}

