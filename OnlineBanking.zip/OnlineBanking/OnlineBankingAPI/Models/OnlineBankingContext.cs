using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;

namespace OnlineBankingAPI.Models
{
    public class OnlineBankingContext : DbContext
    {

        public OnlineBankingContext(DbContextOptions<OnlineBankingContext> options) : base(options) { }

        public DbSet<Users>? User { get; set; }
        public DbSet<Accounts>? Account { get; set; }

        public DbSet<Admin>? Admin { get; set; }

        public DbSet<Beneficiary>? Beneficiary { get; set; }

        public DbSet<Transaction>? Transaction { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            
            modelBuilder.Entity<Users>(entity =>
            {
                entity.Property(u => u.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(u => u.Email)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(u => u.MobileNumber)
                    .IsRequired()
                    .HasMaxLength(15);

                entity.Property(u => u.AadharNumber)
                    .IsRequired()
                    .HasMaxLength(12);

                entity.Property(u => u.DOB)
                    .IsRequired();

                entity.Property(u => u.Status)
                    .HasMaxLength(20);

                modelBuilder.Entity<Users>()
       .HasOne(u => u.Account)
       .WithOne(a => a.User)
       .HasForeignKey<Accounts>(a => a.UserId)
       .OnDelete(DeleteBehavior.Cascade);
            });
            modelBuilder.Entity<Accounts>(entity =>
    {
        // Set UserId to be required and configure the foreign key relationship with Users
        entity.Property(a => a.UserId)
            .IsRequired();

        // Set AccountNumber to be required with a maximum length
        entity.Property(a => a.AccountNumber)
            .IsRequired()
            .HasMaxLength(20); // You can adjust the length as per your requirements

        // Set AccountType to be required
        entity.Property(a => a.AccountType)
            .IsRequired();

        // Set Balance to have a default value of 0 (optional)
        entity.Property(a => a.Balance)
        .HasColumnType("decimal(18,2)")  // 18 digits in total, 2 digits after the decimal point
        .HasDefaultValue(0);


        // Configure the one-to-many relationship with Transaction (Account can have many Transactions)
        entity.HasMany(a => a.Transactions)  // An Account can have many Transactions
            .WithOne(t => t.Account)  // A Transaction has one Account (sender)
            .HasForeignKey(t => t.AccountNumber)  // Foreign Key is AccountId
            .OnDelete(DeleteBehavior.Restrict);  // Optional: Adjust delete behavior as needed

        // Configure the one-to-one relationship with Users (an Account belongs to one User)
        entity.HasOne(a => a.User)  // Each Account belongs to one User
            .WithOne(u => u.Account)  // A User can have one Account
            .HasForeignKey<Accounts>(a => a.UserId)  // Foreign Key is UserId
            .OnDelete(DeleteBehavior.Cascade);  // Optional: Adjust delete behavior as needed
    });
            modelBuilder.Entity<Admin>(entity =>
    {
        // Configure Admin entity
        entity.Property(a => a.AdminName)
            .IsRequired(false);

        entity.Property(a => a.AdminPassword)
            .IsRequired();

        // Configure the one-to-many relationship with Users
        // modelBuilder.Entity<Admin>()
        //     .HasMany(a => a.Users)
        //     .WithOne(u => u.Admin)
        //     .HasForeignKey("AdminId")  // AdminId foreign key in Users (but no column in Users)
        //     .OnDelete(DeleteBehavior.SetNull);
    });
            modelBuilder.Entity<Beneficiary>(entity =>
           {
               // Set BeneficiaryName to be required with a maximum length of 255 characters
               entity.Property(b => b.BeneficiaryName)
                     .IsRequired()
                     .HasMaxLength(255);

               // Set BeneficiaryAccountNumber to be required with a maximum length of 20 characters
               entity.Property(b => b.BeneficiaryAccountNumber)
                     .IsRequired()
                     .HasMaxLength(20);

               // Configure the one-to-many relationship with Transaction
               entity.HasMany(b => b.Transactions)  // A Beneficiary can have many Transactions
                     .WithOne(t => t.Beneficiary)  // A Transaction has one Beneficiary (recipient)
                     .HasForeignKey(t => t.BeneficiaryAccountNumber)  // Foreign Key is BeneficiaryId
                     .OnDelete(DeleteBehavior.Restrict);  // Optional: Adjust delete behavior as needed
           });

            modelBuilder.Entity<Transaction>(entity =>
            {
                // Configure AccountId as a required foreign key to the Accounts table
                entity.Property(t => t.AccountNumber)
                    .IsRequired();

                // Configure BeneficiaryId as a required foreign key to the Beneficiary table
                entity.Property(t => t.BeneficiaryAccountNumber)
                    .IsRequired();

                // Set TransactionType to be required with a maximum length of 10 characters
                entity.Property(t => t.TransactionType)
                    .IsRequired()
                    .HasMaxLength(10); // You can adjust the length if needed

                // Set Amount to be required and define the column type as decimal(15, 2)
                entity.Property(t => t.Amount)
                    .IsRequired()
                    .HasColumnType("decimal(15,2)");

                // Set Date to be required
                entity.Property(t => t.Date)
                    .IsRequired();

                // Set Remark to be optional with a maximum length of 255 characters
                entity.Property(t => t.Remark)
                    .HasMaxLength(255); // Optional Remark field with max length

                // Configure the relationship with the Accounts table (sender)
                entity.HasOne(t => t.Account)  // A Transaction has one Account (sender)
                    .WithMany(a => a.Transactions);  // An Account can have many Transactions

            });


            base.OnModelCreating(modelBuilder);



        }


    }
}
